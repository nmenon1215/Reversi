package cs3500.view.gui;

/**
 * action interface.
 */
public interface Actions {

  // TODO:
  //  - callback methods for p and s?
}
