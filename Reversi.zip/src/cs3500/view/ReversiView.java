package cs3500.view;

public interface ReversiView {

  void setVisible(boolean b);

  void display(boolean show);
}
